// DEVELOPER: Wesley Fegan, IS117-005, Spring 2021
$('#header').load('./common/header.html');